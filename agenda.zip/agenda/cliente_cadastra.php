<?php
include("utils/conectadb.php");
include("utils/verificalogin.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['txtnome'];
    $cpf = $_POST['txtcpf'];
    $tel = $_POST['txttel'];
    $datanasc = $_POST['txtdatanasc'];
    $ativo = $_POST['ativo'];

    $sql = "SELECT COUNT(CLI_CPF) FROM clientes WHERE CLI_CPF = '$cpf'";
    $resultado = mysqli_query($link, $sql);
    $retorno = mysqli_fetch_array($resultado)[0];

    if ($retorno == 1) {
        echo "<script>window.alert('CLIENTE JÁ EXISTE');</script>";
    } else {
        $sql = "INSERT INTO clientes (CLI_NOME, CLI_CPF, CLI_TEL, CLI_DATANASC, CLI_ATIVO)
                VALUES ('$nome', '$cpf', '$tel', '$datanasc', $ativo)";
        mysqli_query($link, $sql);

        echo "<script>
    alert('USUÁRIO CADASTRADO COM SUCESSO!');
    window.location.href = 'backoffice.php';
</script>";

    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CADASTRO DE CLIENTE</title>
    <link rel="stylesheet" href="css/formulario.css">
    <link rel="stylesheet" href="css/global.css">
</head>
<body>
    <div class="global">
        <div class="formulario">
            <a href="backoffice.php"><img src='icons/arrow47.png' width=50 height=50></a>

            <form class='login' action="cliente_cadastra.php" method="post">
                <label>NOME DO CLIENTE</label>
                <input type="text" name="txtnome" placeholder="Digite o nome completo" required>
                
                <label>CPF</label>
                <input type="number" name="txtcpf" placeholder="Digite o CPF" required>
                
                <label>TELEFONE</label>
                <input type="number" name="txttel" placeholder="Digite o telefone" required>
                
                <label>DATA DE NASCIMENTO</label>
                <input type="date" name="txtdatanasc" required>

                <label>STATUS</label>
                <div class="rbativo">
                    <input type="radio" name="ativo" value="1" checked><label>ATIVO</label>
                    <input type="radio" name="ativo" value="0"><label>INATIVO</label>
                </div>

                <input type="submit" value="CADASTRAR">
            </form>
        </div>
    </div>
</body>
</html>
