<?php

// CONEXÃO COM O BANCO DE DADOS
include("utils/conectadb.php");
include("utils/verificalogin.php");

// COLETANDO E PREENCHENDO OS DADOS NOS CAMPOS
$id = $_GET['id']; // COLETANDO O ID VIA GET NA URL

$sql = "SELECT * FROM clientes
        INNER JOIN usuarios ON FK_FUN_ID = CLI_ID WHERE CLI_ID = $id";
$enviaquery = mysqli_query($link, $sql);

// PREENCHENDO OS CAMPOS COM WHILE
while ($tbl = mysqli_fetch_array($enviaquery)) {
    $nomecli = $tbl['CLI_NOME'];
    $cpfcli = $tbl['CLI_CPF'];
    $telefonecli = $tbl['CLI_TEL'];
    $ativocli = $tbl['CLI_ATIVO'];
    $datanasccli = $tbl['CLI_DATANASC'];

    // USUÁRIO
    $usulogin = $tbl['USU_LOGIN'];
    $ususenha = $tbl['USU_SENHA'];
    $usuativo = $tbl['USU_ATIVO'];
}

// APÓS ALTERAÇÕES FAZER O SAVE NO BANCO
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // COLETAR CAMPOS DOS INPUTS POR NAMES PARA VARIÁVEIS PHPs
    $id = $_POST['txtid'];

    $nomecli = $_POST['txtnome'];
    $cpfcli = $_POST['txtcpf'];
    $telefonecli = $_POST['txttelefone'];
    $ativocli = $_POST['ativo'];
    $datanasccli = $_POST['txtdatanasc'];

    // COLETA PARA O USUARIO
    $usulogin = $_POST['txtusuario'];
    $ususenha = $_POST['txtsenha'];

    // INICIANDO QUERIES DE BANCO
    // Query para atualizar os dados do cliente
    $update_cliente = "UPDATE clientes SET 
                       CLI_NOME = '$nomecli', 
                       CLI_CPF = '$cpfcli', 
                       CLI_TEL = '$telefonecli', 
                       CLI_ATIVO = '$ativocli', 
                       CLI_DATANASC = '$datanasccli' 
                       WHERE CLI_ID = $id";

    // Query para atualizar os dados do usuário
    $update_usuario = "UPDATE usuarios SET 
                       USU_LOGIN = '$usulogin', 
                       USU_SENHA = MD5('$ususenha'), 
                       USU_ATIVO = '$usuativo' 
                       WHERE FK_FUN_ID = $id";

    // Executando as queries
    if (mysqli_query($link, $update_cliente) && mysqli_query($link, $update_usuario)) {
        echo "<script>alert('Dados do cliente atualizados com sucesso!');</script>";
    } else {
        echo "<script>alert('Erro ao atualizar os dados do cliente!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/formulario.css">
    <link rel="stylesheet" href="css/global.css">
    <link href="https://fonts.cdnfonts.com/css/master-lemon" rel="stylesheet">
    <title>DADOS DE CLIENTE</title>
</head>
<body>
    <div class="global">
        
        <div class="formulario">
            <!-- FIRULAS Y FIRULAS -->
            <a href="backoffice.php"><img src='icons/arrow47.png' width=50 height=50></a>
            
            <form class='login' action="cliente_cadastra.php" method="post">
                
                <!-- PARA GRAVARMOS REALMENTE O ID DO CLIENTE -->
                <input type='hidden' name='txtid' value='<?= $id?>'>

                <label>NOME DO CLIENTE</label>
                <input type='text' name='txtnome' value="<?= $nomecli ?>" required>
                <br>
                <label>CPF</label>
                <input type='number' name='txtcpf' value="<?= $cpfcli ?>" disabled required>
                <br>
                <label>TELEFONE</label>
                <input type='number' name='txttelefone' value="<?= $telefonecli ?>" required>
                <br>
                <label>DATA DE NASCIMENTO</label>
                <input type='date' name='txtdatanasc' value="<?= $datanasccli ?>" required>
                
                <!-- ESSE RADIO VERIFICA CLIENTE -->
                <div class='rbativo'>
                    <input type="radio" name="ativo" id="ativo" value="1" <?= $ativocli == 1 ? 'checked' : '' ?>><label>ATIVO</label>
                    <br>
                    <input type="radio" name="ativo" id="inativo" value="0" <?= $ativocli == 0 ? 'checked' : '' ?>><label>INATIVO</label>
                </div>
                
                <br>
                <br>
                <br>
                <br>
    
                <!-- AGORA CALASTRAMOS O USUARIO NO SISTEMA -->
                <label>DIGITE LOGIN</label>
                <input type='text' name='txtusuario' value="<?= $usulogin ?>" required>
                <br>
                <label>SENHA</label>
                <input type='password' name='txtsenha' value="<?= $ususenha ?>" required>
                <br>
                
                <label>INICIAR USUARIO COMO:</label>
                <div class='rbativo'>
                    <input type="radio" name="usuativo" id="ativo" value="1" <?= $usuativo == 1 ? 'checked' : '' ?>><label>ATIVO</label>
                    <br>
                    <input type="radio" name="usuativo" id="inativo" value="0" <?= $usuativo == 0 ? 'checked' : '' ?>><label>INATIVO</label>
                </div>

                <br>
                <input type='submit' value='SALVAR ALTERAÇÕES'>
            </form>
            
            <br>

        </div>
    </div>
</body>
</html>
