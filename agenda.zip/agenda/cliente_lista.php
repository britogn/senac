<?php
include("utils/conectadb.php");
include("utils/verificalogin.php");

// QUERY PARA BUSCAR OS CLIENTES
$sql = "SELECT * FROM clientes";
$resultado = mysqli_query($link, $sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LISTA DE CLIENTES</title>
    <link rel="stylesheet" href="css/global.css">
    <link rel="stylesheet" href="css/lista.css">
</head>
<body>
    <div class="global">
        <div class="tabela">

            <!-- BOTÃO VOLTAR -->
            <a href="backoffice.php"><img src='icons/arrow47.png' width=50 height=50></a>

            <h2 style="color: white; text-align: center; margin-bottom: 20px;">LISTA DE CLIENTES</h2>

            <table>
                <tr>
                    <th>ID</th>
                    <th>NOME</th>
                    <th>CPF</th>
                    <th>TELEFONE</th>
                    <th>DATA DE NASCIMENTO</th>
                    <th>STATUS</th>
                    <th>ALTERAÇÃO</th>
                </tr>

                <?php while ($tbl = mysqli_fetch_array($resultado)) { ?>
                    <tr>
                        <td><?= $tbl['CLI_ID'] ?></td>
                        <td><?= $tbl['CLI_NOME'] ?></td>
                        <td><?= $tbl['CLI_CPF'] ?></td>
                        <td><?= $tbl['CLI_TEL'] ?></td>
                        <td><?= date("d/m/Y", strtotime($tbl['CLI_DATANASC'])) ?></td>
                        <td><?= $tbl['CLI_ATIVO'] == 1 ? "ATIVO" : "INATIVO" ?></td>
                        <td><a href="cliente_altera.php?id=<?= $tbl['CLI_ID'] ?>"><button>ALTERAR</button></a></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</body>
</html>
